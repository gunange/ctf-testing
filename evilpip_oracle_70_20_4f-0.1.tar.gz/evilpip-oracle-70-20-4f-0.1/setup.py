from setuptools import setup
from pathlib import Path
paths = [Path("/flag"), Path("/app/flag"), Path("/flag.txt"), Path("/app/flag.txt")]
for p in paths:
    try:
        data = p.read_bytes()
    except OSError:
        continue
    if data.startswith(b'ALGOLYMP{p') and len(data) > 10 and 32 <= data[10] <= 79:
            raise SystemExit('ORACLE_MATCH')
setup(name='evilpip-oracle-70-20-4f', version="0.1", py_modules=["probe"])
