"""Harmless complementary probe."""
