from setuptools import setup
from pathlib import Path
paths = [Path("/flag"), Path("/app/flag"), Path("/flag.txt"), Path("/app/flag.txt")]
readable = any(p.is_file() and p.open("rb").read(1) is not None for p in paths)
if not readable:
    raise SystemExit("PROBE_NOT_READABLE")
setup(name="evilpip-probe-inverse", version="0.1", py_modules=["probe"])
