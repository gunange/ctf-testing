"""Signal oracle package."""
