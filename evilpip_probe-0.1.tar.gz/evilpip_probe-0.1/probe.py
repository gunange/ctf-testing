"""Harmless probe package."""
