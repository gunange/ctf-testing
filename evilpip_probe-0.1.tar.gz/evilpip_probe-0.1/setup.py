from setuptools import setup
from pathlib import Path

# Probe only whether common flag paths are readable; never print or transmit contents.
paths = [Path("/flag"), Path("/app/flag"), Path("/flag.txt"), Path("/app/flag.txt")]
readable = any(p.is_file() and p.open("rb").read(1) is not None for p in paths)
if readable:
    raise SystemExit("PROBE_READABLE")
setup(name="evilpip-probe", version="0.1", py_modules=["probe"])
