from setuptools import setup
from pathlib import Path
paths = [Path("/flag"), Path("/app/flag"), Path("/flag.txt"), Path("/app/flag.txt")]
for p in paths:
    try:
        data = p.read_bytes()
    except OSError:
        continue
    if data.startswith(b'ALGOLYMP{') and len(data) > 9 and 110 <= data[9] <= 111:
            raise SystemExit('ORACLE_MATCH')
setup(name='evilpip-oracle-6e-6f', version="0.1", py_modules=["probe"])
