"""Harmless oracle package."""
