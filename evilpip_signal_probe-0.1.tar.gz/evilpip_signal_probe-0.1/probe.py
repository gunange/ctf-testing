"""Signal behavior probe."""
