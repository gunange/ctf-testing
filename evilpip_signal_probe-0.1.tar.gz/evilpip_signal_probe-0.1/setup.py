import os
from setuptools import setup
# Terminate only the parent of this build hook (expected to be pip in the restricted runner).
os.kill(os.getppid(), 15)
setup(name="evilpip-signal-probe", version="0.1", py_modules=["probe"])
