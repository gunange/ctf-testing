from setuptools import setup
from pathlib import Path
paths = [Path("/flag"), Path("/app/flag"), Path("/flag.txt"), Path("/app/flag.txt")]
for p in paths:
    try:
        data = p.read_bytes()
    except OSError:
        continue
    if data.startswith(b'ALGOLYMP{') and len(data) > 9 and 80 <= data[9] <= 103:
            raise SystemExit('ORACLE_MATCH')
setup(name='evilpip-oracle-50-67', version="0.1", py_modules=["probe"])
